package netscope.mango.educy;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.widget.ProgressBar;

import java.util.Timer;
import java.util.TimerTask;

public class Splash extends Activity {
    long Delay = 3000;
    ProgressBar pro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        pro=(ProgressBar)findViewById(R.id.progress);
        Timer RunSplash = new Timer();
        TimerTask ShowSplash = new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(Splash.this, Walkthrough.class);
                startActivity(intent);
                finish();
            }
        };

        RunSplash.schedule(ShowSplash, Delay);
        pro.getIndeterminateDrawable().setColorFilter(Color.RED, PorterDuff.Mode.MULTIPLY);
    }
}

