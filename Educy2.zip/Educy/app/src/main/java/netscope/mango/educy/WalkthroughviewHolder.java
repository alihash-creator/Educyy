package netscope.mango.educy;


public interface WalkthroughviewHolder {

    void onItemSelected();

    void onItemClear();
}
