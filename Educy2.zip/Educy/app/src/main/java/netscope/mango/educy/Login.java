package netscope.mango.educy;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.nfc.Tag;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.GoogleAuthProvider;

public class Login extends GABaseActivity {
    private static final int RC_SIGN_IN = 21;
    private SignInButton signInButton;
    private Button logoutBtn;
    private TextView nameText;
    private boolean Registered;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        nameText = (TextView) findViewById(R.id.textname);
        signInButton = (SignInButton) findViewById(R.id.signin_btn);


        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        Registered = preferences.getBoolean("Registered", false);


        if (Registered) {

            signInButton.setVisibility(View.INVISIBLE);
            nameText.setVisibility(View.VISIBLE);

            nameText.setText("welcome " + mAuth.getCurrentUser().getDisplayName());

            Intent i=new Intent(Login.this,Priority.class);
            startActivity(i);
            finish();
        } else {

            signInButton.setVisibility(View.VISIBLE);
            nameText.setVisibility(View.INVISIBLE);


        }


        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signIn();

            }
        });
    }



    private void signIn() {

        Intent signIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signIntent,RC_SIGN_IN);
        Log.e(TAG, "signIn: signIn is creating");


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.e(TAG, "onActivityResult: is being created");

        if (resultCode == Activity.RESULT_OK){

            if (requestCode==RC_SIGN_IN){

                GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);

                if (result.isSuccess()){

                    GoogleSignInAccount account = result.getSignInAccount();

                    firebaseAuthWithGoogle(account);
                }


            }

        }

    }

    private void firebaseAuthWithGoogle(GoogleSignInAccount account) {

        showProgressDialog();


        Log.e(TAG, "firebaseAuthWithGoogle: started");

        AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(),null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){

                            Log.e(TAG, "onComplete: google account task is successful");

                            //to save email in shared preference
                            String userEmail = mAuth.getCurrentUser().getEmail();
                            String userName = mAuth.getCurrentUser().getDisplayName();


                            signInButton.setVisibility(View.INVISIBLE);

                            nameText.setVisibility(View.VISIBLE);


                            nameText.setText("welcome - "+userName);


                            Log.e(TAG, "onComplete: user name and user email is "+userName+userEmail);


                            SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
                            SharedPreferences.Editor editor = preferences.edit();

                            editor.putBoolean("Registered",true);
                            editor.putString("userEmail",userEmail);
                            editor.putString("userName",userName);

                            editor.apply();


                            Log.e(TAG, "onComplete: shared preference value is saved");

                            dismissProgressDialog();


                        }

                    }
                });

    }
}
