package netscope.mango.educy;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import static android.app.Activity.RESULT_OK;

/**
 * Created by Anonymous on 11/28/2018.
 */

public class Teacher4 extends Fragment {
    Button selectfile, upload, fetchfiles;
    TextView notification;
    ProgressDialog progressDialog;
    Uri pdfUri;//Uri are actually URLs that are meant for local storage
    FirebaseStorage storage;//used for uploading files .. Ex//pdf
    FirebaseDatabase database;//used to store URLs of uploading files...


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.teacher4, container, false);
        storage = FirebaseStorage.getInstance(); //return an object of firebase storage
        database = FirebaseDatabase.getInstance(); //return an object of firebase database


        selectfile = (Button) view.findViewById(R.id.selectFile);
        upload = (Button) view.findViewById(R.id.upload);
        notification = (TextView) view.findViewById(R.id.notification);

        selectfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                selectPdf();

            }
        });

        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (pdfUri != null) {//the user has selected the file
                    uploadFile(pdfUri);
                } else {
                    Toast.makeText(getActivity(), "please select a file..", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    private void uploadFile(Uri pdfUri) {

        progressDialog = new ProgressDialog(getActivity());
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setTitle("Uploading File...");
        progressDialog.setProgress(0);
        progressDialog.show();

        final String fileName = System.currentTimeMillis() + ".pdf";
        final String fileName1 = System.currentTimeMillis() + "";

        StorageReference storageReference = storage.getReference();//return root path
        final StorageReference storageReferenceImage = storageReference.child("uploads").child(fileName);
        storageReferenceImage.putFile(pdfUri).continueWith(new Continuation<UploadTask.TaskSnapshot, Task<? extends Uri>>() {
            @Override
            public Task<? extends Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                if (!task.isSuccessful()) {
                    throw task.getException();
                }
                return storageReferenceImage.getDownloadUrl();
            }
        }).addOnCompleteListener(new OnCompleteListener<Task<? extends Uri>>() {
            @Override
            public void onComplete(@NonNull Task<Task<? extends Uri>> task) {
                String downloadImageUrl = task.getResult().toString();
//                String url = taskSnapshot.getDownloadUrl().toString();//return the url of ur upload file
                //store the url in the real time database

                DatabaseReference reference = database.getReference();//return the path to root

                reference.child(fileName1).setValue(downloadImageUrl).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(getActivity(), "File successfully Uploaded", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(getActivity(), "File not successfully Uploaded", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
//        })
//                .addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
//            @Override
//            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
//
//
//            }
//        }).addOnFailureListener(new OnFailureListener() {
//            @Override
//            public void onFailure(@NonNull Exception e) {
//                Toast.makeText(getActivity(), "File not successfully Uploaded", Toast.LENGTH_SHORT).show();
//
//            }
//        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
//            @Override
//            public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
//
//                //track the progress of our upload
//                int currentprogress = (int) (100 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());
//                progressDialog.setProgress(currentprogress);
//
//            }
        });
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == 9 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            selectPdf();
        } else {
            Toast.makeText(getActivity(), "please provide permission..", Toast.LENGTH_SHORT).show();
        }
    }

    private void selectPdf() {
        //to offer user to select a file using file manager
        //we will be using an intent
        Intent intent = new Intent();
        intent.setType("application/pdf");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent, 86);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        //check whether user has selected a file or not (ex:pdf)
        if (requestCode == 86 && requestCode == RESULT_OK && data != null) {

            pdfUri = data.getData();//return the uri of selected files
            notification.setText("A file is selected : " + data.getData().getLastPathSegment());
        } else {
            Toast.makeText(getActivity(), "please select a file.", Toast.LENGTH_SHORT).show();
        }
    }
}
