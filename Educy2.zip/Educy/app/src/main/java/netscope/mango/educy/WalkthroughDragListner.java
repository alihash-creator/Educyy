package netscope.mango.educy;
import android.support.v7.widget.RecyclerView;


public interface WalkthroughDragListner {


    void onStartDrag(RecyclerView.ViewHolder viewHolder);

    void onFinishDrag();

}
