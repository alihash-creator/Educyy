package netscope.mango.educy;
public interface CatListner {
    void itemClickedAdd();
    void itemClickedRemove();
}